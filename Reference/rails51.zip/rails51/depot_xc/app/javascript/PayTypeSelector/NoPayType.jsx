import React from 'react'

class NoPayType extends React.Component {
  render() {
    return (<div></div>);
  }
}
export default NoPayType
